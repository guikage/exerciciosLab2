#ifndef _relatorios_
#define _relatorios_

#include "carros.h"
#include "clientes.h"
#include "locacao.h"

void r1(LLocacoes *l);
void r2(LLocacoes *l);
void r3(LLocacoes *l);
void r4(LCarros *l);
void r5(LCarros *l);

#endif
